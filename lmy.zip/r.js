var Ga=console.log.bind(console);

var UD=function(x, d){
  if(x===undefined){return d;}
  else{return x;}
};

var gtThanNumPtn=function(num, allowEq){
  allowEq=UD(allowEq, false);
  var numArr=num.toString().split('');
  var _t=[];
  for(var k in numArr){
    _t.push(parseInt(numArr[k]));
  }
  numArr=_t;
  var first=numArr[0];
  
  var branch=[];

  //前缀大于分支
  if(first<9-1){
    var s1='['+(first+1)+'-'+(9)+']';
    if(numArr.length>1){s1+='\\d{'+(numArr.length-1)+'}';}
    branch.push(s1);
  }else if(first==9-1){
    var s1='[9]';
    if(numArr.length>1){s1+='\\d{'+(numArr.length-1)+'}';}
    branch.push(s1);
  }else{
    //如first===9, 则不存在前缀大于分支
  }
  
  //前缀相同分支
  if(numArr.length>1){
    var nextNum=num.toString().replace(/^\d/, '');
    var _sub=gtThanNumPtn(nextNum, allowEq);
    if(_sub!=='%'){
      var s2=first+_sub;
      branch.push(s2);
    }
  }else{
    if(allowEq){
      var s2=first;
      branch.push(s2);
    }
  }

  if(branch.length==0){
    //如first是9,且numArr.length==0, 且allowEq==false, 则可能永不匹配.
    return '%';
  }
  //前缀小于分支则无意义.
  return '('+branch.join('|')+')';
};

0 && (function(){
  var ptn=new RegExp(gtThanNumPtn(8999, false));
  Ga(ptn.test('8998'));
  Ga(ptn.test('8999'));
  Ga(ptn.test('9000'));
  Ga(ptn)
})()

var ltThanNumPtn=function(num, allowEq){
  allowEq=UD(allowEq, false);
  var numArr=num.toString().split('');
  var _t=[];
  for(var k in numArr){
    _t.push(parseInt(numArr[k]));
  }
  numArr=_t;
  var first=numArr[0];
  
  if(numArr.length===0){
    return '';
  }
  var branch=[];

  //前缀大于分支无意义

  //前缀相同分支
  if(numArr.length>1){
    var nextNum=num.toString().replace(/^\d/, '');
    var _sub=ltThanNumPtn(nextNum, allowEq);
    if(_sub!=='%'){
      var s2=first.toString()+_sub;
      //Ga(s2, '@@#', nextNum)
      branch.push(s2);
    }
  }else{
    if(allowEq){
      var s2='['+first.toString()+']';
      branch.push(s2);
    }
  }
  //前缀小于分支.
  if(first>1){
    var s3='[0-'+(first-1)+']';
    if(numArr.length>1){s3+='\\d{'+(numArr.length-1)+'}';}
    branch.push(s3);
  }else if(first===1){
    var s3='[0]';
    if(numArr.length>1){s3+='\\d{'+(numArr.length-1)+'}';}
    branch.push(s3);
  }else{
    //如first是0, 不存在此分支
  }
  if(branch.length==0){
    //如first是0,且numArr.length==0, 且allowEq==false, 则可能永不匹配.
    return '%';
  }
  return '('+branch.join('|')+')';
};

0 && (function(){
  var ptn=new RegExp(ltThanNumPtn(1000, false));
  Ga(ptn.test('1001'));
  Ga(ptn.test('1000'));
  Ga(ptn.test('0999'));
  Ga(ptn)
})()


var regRange=function(start, end, startEq, endEq){
  startEq=UD(startEq, true);
  endEq=UD(endEq, true);

  //Z\d5
  var s2num=function(s){
    var m=s.match(/Z0*(\d+)/i);
    return parseInt(m[1]);
  };
  
  var startNum=s2num(start);
  var endNum=s2num(end);
  
  var a1=Math.min(startNum, endNum);
  var a2=Math.max(startNum, endNum);
  var startNum=a1;
  var endNum=a2;
  

  var _a1=startNum.toString().split('');
  var _a2=endNum.toString().split('');
  _a1=(new Array(_a2.length-_a1.length)).concat(_a1.slice());
  

  var commonPrefix='Z';
  var idx=0;
  var newStart=0;
  var idxEdge=_a1.length;
  while(idx<idxEdge){
    if(_a1[idx]!==_a2[idx]){
      break;
    }else{
      commonPrefix+=UD(_a1[idx], 0).toString();
      newStart=idx+1;
    }
    idx+=1;
  }

  _a1=_a1.slice(newStart);
  _a2=_a2.slice(newStart);
  
  if(_a1.length===0){
    if(!(startEq && endEq)){
      alert('您输入的模式开始和结束位置相同, 且不接受两端位置, 此种特殊情况不予以接受')
    }else{
      return commonPrefix;
    }
  }

  var first1=_a1[0];
  var first2=_a2[0];
  
  var branch=[];
  //和最小分支相同first值分支
  if(_a1.length>1){
    var _sub=gtThanNumPtn((_a1.slice(1).join('')), startEq);
    if(_sub!=='%'){
      var s=first1+_sub;
      branch.push(s);
    }
  }else{
    if(startEq){
      var s=first1
      branch.push(s);
    }
  }

  //前缀之间分支
  if(first2-first1>0){
    if(first2-first1>=3){
      G.a(first2, first1+1)
      var s='['+(first1+1)+'-'+(first2-1)+']';
    }else if(first2-first1==2){
      var s='['+(first1+1)+']';
    }
    if(_a1.length>1){
      s+='\\d{'+(_a1.length-1)+'}';
    }
    branch.push(s);
  }

  //和最大分支相同first值分支
  if(_a2.length>1){
    var _sub=ltThanNumPtn((_a2.slice(1).join('')), endEq);
    if(_sub!=='%'){
      var s=first2+_sub;
      branch.push(s);
    }
  }else{
    if(endEq){
      var s=first2.toString()
      branch.push(s);
    }
  };

  var r=commonPrefix+'('+branch.join('|')+')';

  //Ga(branch, '@@');
  return r;
};

0 && (function(){
  var ptn=new RegExp(regRange('z31000','z32000', true, true), 'i');
  Ga(ptn)
  Ga(ptn.test('z30999'))
  Ga(ptn.test('z31000'))
  Ga(ptn.test('z31001'))

  Ga(ptn.test('z31999'))
  Ga(ptn.test('z32000'))
  Ga(ptn.test('z32001'))
})();


$(function(){
  var $i1=$('.i1');
  var $i2=$('.i2');
  var $cal=$('.cal');
  var $test=$('.test');
  var $ptn=$('.ptn');
  var $testStr=$('.test-string');
  var $i1In=$('.i1-include');
  var $i2In=$('.i2-include');
  var $result=$('.result');
  var $testResult=$('.test-result');

  $cal.click(function(){
    var r=regRange($i1.val(), $i2.val(), $i1In.prop('checked'),  $i2In.prop('checked'));
    $ptn.val(r);
    $result.text(r);
  });
  $test.click(function(){
    var ptn=new RegExp($ptn.val(), 'i');
    var testStr=$testStr.val();
    if(ptn.test(testStr)){
      $testResult.text('匹配');
    }else{
      $testResult.text('不匹配');
    }
  })
  
  $i1In.change(function(){$cal.click();});
  $i2In.change(function(){$cal.click();});

  //自动化测试初始化;
  0 && (function(){
    $i1.val('z31000');
    $i2.val('z32000');
    $testStr.val('z32000');
    $cal.click();
    $test.click();
  })();
})
